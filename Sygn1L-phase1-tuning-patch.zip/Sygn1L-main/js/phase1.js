// /js/phases/phase1.js
// PHASE 1: EXPLORATION
// Localised phase gameplay: buffs, synchronicity meter, extra CRT scopes, timer + replay.
// Adds: Phase-local passive gain, phase-local autosave, and phase-local AI comms triggers.
// Adds: Scripted character comms (no AI cooldown) triggered by events/milestones.

import { clamp, fmt } from "../state.js";
import { lvl } from "../economy.js";

const PHASE_ID = 1;

// ----------------------------
// Phase-owned music (single-instance safe)
// ----------------------------
const MUSIC_KEY = "phase1_apollo";
const MUSIC_SRC_PRIMARY = "audio/Apollo.mp3";
const MUSIC_SRC_FALLBACK = "audio/apollo.mp3"; // case-sensitive hosting fallback

function ensureSingleMusic(audio) {
  const prevKey = window.__sygn1l_currentMusicKey;
  if (prevKey && prevKey !== MUSIC_KEY && audio?.stop) {
    audio.stop(prevKey, { fadeOut: 0.25 });
  }
  if (audio?.stop) audio.stop(MUSIC_KEY, { fadeOut: 0.05 });
  window.__sygn1l_currentMusicKey = MUSIC_KEY;
}

// ----------------------------
// Phase 1 Scripted Comms (no AI cooldown)
// ----------------------------
const P1_CAST = {
  OPS: "MORRIS HARDY // OPS",
  CONTROL: "MOTHER // CONTROL",
  SWF: "DYSON GREEN // SWF (PRIVATE)",
  TECH: "ALICE CHEN // TECH"
};

function p1Say(api, from, text) {
  api.ui.pushLog("comms", from, text);
}

function pick(lines) {
  return lines[Math.floor(Math.random() * lines.length)];
}

function ensureCommsFlags(d) {
  d._p1_comms ||= {
    began: false,
    firstPing: false,
    ping10: false,
    gotReturn: false,
    firstBuff: false,
    hit30: false,
    hit60: false,
    hit85: false,
    corr25: false,
    corr50: false,
    reminderIdle: 0
  };
  return d._p1_comms;
}

// ----------------------------
// Phase 1 Buffs (phase-owned upgrade list)
// ----------------------------
const P1_BUFFS = [
  {
    id: "p1_filter",
    name: "BANDPASS FILTER",
    unlock: 20,
    base: 28,
    mult: 2.05,
    desc: "Cleaner returns. Ping gains x1.25. Sync growth x1.30. Passive signal multiplier."
  },
  {
    id: "p1_surge",
    name: "SIGNAL SURGE",
    unlock: 45,
    base: 65,
    mult: 2.35,
    desc: "Illegal boost. After each PING: x5 click gain for 6s, plus corruption bleed-off."
  },
  {
    id: "p1_gain",
    name: "CRYO AMP",
    unlock: 80,
    base: 160,
    mult: 2.18,
    desc: "More power in the dark. Ping gains x1.60. Passive signal multiplier. Slightly aggravates corruption."
  },
  {
    id: "p1_cancel",
    name: "NOISE CANCELLER",
    unlock: 300,
    base: 1100,
    mult: 2.25,
    desc: "Suppresses corruption pressure. Strong corruption bleed + reduced corruption drag."
  },
  {
    id: "p1_lock",
    name: "HARMONIC LOCK",
    unlock: 2200,
    base: 10500,
    mult: 2.35,
    desc: "Synergy engine. Multiplies passive signal/sec and Sync growth per other buff owned."
  },
  {
    id: "p1_bias",
    name: "QUANTUM PHASE BIAS",
    unlock: 15000,
    base: 95000,
    mult: 2.45,
    desc: "Surf the static. Converts corruption into extra passive signal + Sync momentum."
  }
];

// ----------------------------
// Phase data
// ----------------------------
function ensurePhaseData(api) {
  api.state.phaseData ||= {};
  api.state.phaseData[PHASE_ID] ||= {
    pings: 0,
    sync: 0,
    complete: false,
    startAtMs: Date.now(),
    endAtMs: 0,
    bestTimeSec: 0,

    // Ping momentum (rewards cadence; decays quickly if you stop)
    _pingChain: 0,
    _pingChainHold: 0,

    // Temporary surge window after ping (from SIGNAL SURGE)
    _surgeTimer: 0,

    _p1_sps: 0,
    _osc: null,
    _bars: null,

    _autosaveAccum: 0,
    _cloudSaveAccum: 0,
    _commsAccum: 0,
    _aiPulseAccum: 0
  };
  return api.state.phaseData[PHASE_ID];
}

function fmtTime(sec) {
  const s = Math.max(0, Math.floor(sec));
  const mm = String(Math.floor(s / 60)).padStart(2, "0");
  const ss = String(s % 60).padStart(2, "0");
  return `${mm}:${ss}`;
}

function fmtTimeMs(ms) {
  const t = Math.max(0, Math.floor(ms));
  const sec = Math.floor(t / 1000);
  const mm = String(Math.floor(sec / 60)).padStart(2, "0");
  const ss = String(sec % 60).padStart(2, "0");
  const cs = String(Math.floor((t % 1000) / 10)).padStart(2, "0"); // centiseconds
  return `${mm}:${ss}.${cs}`;
}

// ----------------------------
// Phase 1 DOM + renderers
// ----------------------------
function ensurePhase1HUD(api) {
  const { styles } = api;

  const headerPad = document.querySelector("header.card .pad");
  const scopeWrap = document.querySelector(".scopeWrap");
  if (!headerPad || !scopeWrap) return;

  if (document.getElementById("p1Osc")) return;

  const row = document.createElement("div");
  row.id = "p1VizRow";
  row.className = "p1VizRow";

  const scopeWrapParent = scopeWrap.parentElement;
  if (scopeWrapParent) {
    scopeWrapParent.insertBefore(row, scopeWrap);
    row.appendChild(scopeWrap);
  }

  const osc = document.createElement("div");
  osc.className = "scopeWrap p1OscWrap";
  osc.innerHTML = `
    <div class="scopeTop">
      <div>SYNC OSC</div>
      <div class="scopeMeta" id="p1OscLabel">SYNC: 0%</div>
    </div>
    <canvas id="p1Osc"></canvas>
  `;
  row.appendChild(osc);

  const bar = document.createElement("div");
  bar.className = "p1SyncBar";
  bar.innerHTML = `
    <div class="p1SyncTop">
      <div class="p1SyncTitle">SYNCHRONICITY</div>
      <div class="p1SyncMeta" id="p1SyncMeta">0.0%</div>
    </div>
    <div class="p1Bar"><div class="p1Fill" id="p1SyncFill"></div></div>
    <div class="p1SpsRow">
      <span class="chip p1Chip" id="p1SpsChip">P1 +0.00/s</span>
    </div>
    <canvas id="p1Bars"></canvas>
  `;
  headerPad.insertBefore(bar, document.getElementById("ping"));

  const replay = document.createElement("button");
  replay.id = "p1Replay";
  replay.className = "big";
  replay.style.display = "none";
  replay.textContent = "REPLAY PHASE (TIME TRIAL)";
  replay.addEventListener("click", () => {
    const ok = window.confirm(
      "Replay Phase 1?\n\nThis restarts Phase 1 progression (timer + synchronicity) and resets SIGNAL/TOTAL/CORRUPTION to 0 for a clean run."
    );
    if (!ok) return;

    const d = ensurePhaseData(api);
    d.pings = 0;
    d.sync = 0;
    d.complete = false;
    d.startAtMs = Date.now();
    d.endAtMs = 0;

    for (const b of P1_BUFFS) {
      if (api.state.up && b.id in api.state.up) api.state.up[b.id] = 0;
    }

    api.state.signal = 0;
    api.state.total = 0;
    api.state.corruption = 0;

    replay.style.display = "none";
    api.ui.popup("OPS", "Phase 1 reset. Beat your best time.");
    api.ui.pushLog("log", "SYS", "PHASE 1 REPLAY INITIATED.");
    api.touch();
  });
  headerPad.insertBefore(replay, document.getElementById("ping"));

  // Leaderboard buttons (Phase 1 UI)
  if (!document.getElementById("p1LbRow")) {
    const row2 = document.createElement("div");
    row2.id = "p1LbRow";
    row2.className = "p1LbRow";
    row2.innerHTML = `
      <button id="p1GlobalLb" class="big">GLOBAL LEADERBOARD</button>
      <button id="p1MyTimes" class="big">MY TIME TRIALS</button>
    `;
    headerPad.insertBefore(row2, document.getElementById("ping"));

    const gBtn = row2.querySelector("#p1GlobalLb");
    const mBtn = row2.querySelector("#p1MyTimes");

    gBtn?.addEventListener("click", async () => {
      const w = api.ui.modal("GLOBAL LEADERBOARD", "<div class='muted'>LOADING…</div>");
      try {
        if (!api.saves?.isSignedIn?.()) {
          w.body.innerHTML = "<div class='muted'>SIGN IN TO VIEW GLOBAL LEADERBOARDS.</div>";
          return;
        }

        const res = await api.saves.fetchGlobalLeaderboards({ limitPerPhase: 25 });
        const phases = res?.phases || {};
        const phaseNums = Object.keys(phases)
          .map((n) => Number(n))
          .filter(Boolean)
          .sort((a, b) => a - b)
          .filter((n) => (phases[n] || []).length > 0);

        if (!phaseNums.length) {
          w.body.innerHTML = "<div class='muted'>NO COMPLETIONS ON RECORD YET.</div>";
          return;
        }

        const parts = [];
        for (const p of phaseNums) {
          const rows = phases[p] || [];
          parts.push(`<h3>PHASE ${p}</h3>`);
          rows.forEach((r, idx) => {
            const name = String(r.username || "UNKNOWN");
            const time = fmtTimeMs(Number(r.time_ms) || 0);
            const when = r.updated_at ? new Date(r.updated_at).toLocaleString() : "";
            parts.push(`
              <div class='sygLbRow'>
                <div class='sygLbLeft'>
                  <div class='sygLbName'>#${idx + 1} ${name}</div>
                  <div class='sygLbMeta'>${when}</div>
                </div>
                <div class='sygLbTime'>${time}</div>
              </div>
            `);
          });
        }
        w.body.innerHTML = parts.join("");
      } catch (e) {
        w.body.innerHTML = `<div class='muted'>LEADERBOARD ERROR: ${String(e?.message || e)}</div>`;
      }
    });

    mBtn?.addEventListener("click", () => {
      const pd = api.state?.phaseData || {};
      const nums = Object.keys(pd)
        .map((n) => Number(n))
        .filter(Boolean)
        .sort((a, b) => a - b)
        .filter((n) => pd[n]?.complete && pd[n]?.bestTimeSec);

      if (!nums.length) {
        api.ui.modal("MY TIME TRIALS", "<div class='muted'>NO COMPLETED PHASE TIMES YET.</div>");
        return;
      }

      const parts = [];
      for (const p of nums) {
        const best = fmtTime(Number(pd[p].bestTimeSec) || 0);
        parts.push(`<div class='sygLbRow'><div class='sygLbLeft'><div class='sygLbName'>PHASE ${p}</div><div class='sygLbMeta'>PERSONAL BEST</div></div><div class='sygLbTime'>${best}</div></div>`);
      }
      api.ui.modal("MY TIME TRIALS", parts.join(""));
    });
  }

  const chipHost = document.querySelector("#syncChip")?.parentElement;
  if (chipHost && !document.getElementById("p1TimerChip")) {
    const chip = document.createElement("span");
    chip.id = "p1TimerChip";
    chip.className = "chip";
    chip.textContent = "T+ 00:00";
    chipHost.appendChild(chip);
  }

  styles.add(
    "p1-ui",
    `
    /* Phase 1: keep Array Scope + Sync Osc on one row.
       Layout rule: row height drives the square oscilloscope; scope takes the remaining width.
       Target ratio: ~80% scope / ~20% osc via height ~= 20vw.
    */
    html[data-phase='1'] .p1VizRow{
      display:flex;
      gap:14px;
      margin-top:12px;
      align-items:stretch;
      width:100%;
      height:clamp(112px, 20vw, 176px);
    }
    html[data-phase='1'] .p1VizRow > .scopeWrap{ height:100%; }
    /* Main scope panel grows */
    html[data-phase='1'] .p1VizRow > .scopeWrap:not(.p1OscWrap){
      flex:1 1 auto;
      min-width:0;
    }
    /* Osc panel stays square; width follows height */
    html[data-phase='1'] .p1VizRow > .p1OscWrap{
      flex:0 0 auto;
      aspect-ratio:1/1;
    }

    html[data-phase='1'] .scopeWrap{ border-radius:14px; }
    html[data-phase='1'] .p1OscWrap, html[data-phase='1'] .scopeWrap{ overflow:hidden; }

    html[data-phase='1'] .p1LbRow{ display:flex; gap:10px; margin:10px 0 6px; }
    html[data-phase='1'] .p1LbRow button.big{ flex:1 1 0; padding:14px 12px; font-size:12px; }

    html[data-phase='1'] .p1OscWrap::before,
    html[data-phase='1'] .scopeWrap::before,
    html[data-phase='1'] .p1SyncBar::before{
      content:'';
      position:absolute;
      inset:0;
      pointer-events:none;
      background:repeating-linear-gradient(
        to bottom,
        rgba(255,255,255,.05),
        rgba(255,255,255,.05) 1px,
        rgba(0,0,0,0) 4px,
        rgba(0,0,0,0) 8px
      );
      opacity:.10;
      mix-blend-mode:screen;
    }

    html[data-phase='1'] .p1SyncBar{ position:relative; margin-top:14px; padding:10px 12px 8px; border:1px solid rgba(255,255,255,.06); border-radius:14px; background:rgba(0,0,0,.38); }
    html[data-phase='1'] .p1SyncTop{ display:flex; justify-content:space-between; align-items:baseline; gap:10px; }
    html[data-phase='1'] .p1SyncTitle{ letter-spacing:.16em; font-size:10px; color:rgba(223,255,232,.72); }
    html[data-phase='1'] .p1SyncMeta{ font-size:11px; color:rgba(223,255,232,.88); }

    html[data-phase='1'] .p1Bar{ height:10px; border-radius:999px; overflow:hidden; background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.06); margin-top:8px; }
    html[data-phase='1'] .p1Fill{ height:100%; width:0%; background:linear-gradient(90deg, rgba(57,255,106,.25), rgba(88,255,174,.90)); box-shadow:0 0 18px rgba(57,255,106,.18); }

    html[data-phase='1'] .p1SpsRow{ margin-top:8px; display:flex; justify-content:flex-end; }
    html[data-phase='1'] .p1Chip{ font-size:11px; opacity:.92; }

    /* Let canvases size themselves to the row height (renderers use clientHeight). */
    html[data-phase='1'] #scope{ display:block; width:100%; height:100%; }
    html[data-phase='1'] canvas#p1Osc{ display:block; width:100%; height:100%; }
    html[data-phase='1'] canvas#p1Bars{ display:block; width:100%; height:34px; margin-top:8px; opacity:.92; }

    html[data-phase='1'] #ping.afford{ filter: drop-shadow(0 0 10px rgba(90,255,170,.20)); }
  `
  );
}

function teardownPhase1HUD(api) {
  api.styles.remove("p1-ui");

  const scopeWrap = document.querySelector(".scopeWrap");
  const headerPad = document.querySelector("header.card .pad");
  const ping = document.getElementById("ping");
  if (scopeWrap && headerPad && ping) {
    const row = document.getElementById("p1VizRow");
    if (row && row.contains(scopeWrap)) {
      headerPad.insertBefore(scopeWrap, ping);
    }
  }

  document.getElementById("p1VizRow")?.remove();
  document.querySelector(".p1SyncBar")?.remove();
  document.getElementById("p1Replay")?.remove();
  document.getElementById("p1TimerChip")?.remove();
}

// ----------------------------
// Canvas renderers
// ----------------------------
function createOscRenderer(canvas) {
  if (!canvas) return null;
  const ctx = canvas.getContext("2d", { alpha: false });
  let dpr = 1;
  let w = 0;
  let h = 0;

  function resize() {
    dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
    const cssW = canvas.clientWidth || 300;
    // Height is driven by CSS (Phase 1 row layout). Fall back if not measurable yet.
    const cssH = canvas.clientHeight || 84;
    canvas.width = Math.floor(cssW * dpr);
    canvas.height = Math.floor(cssH * dpr);
    w = canvas.width;
    h = canvas.height;
  }

  function draw(t, sync, corr) {
    if (!w || !h) return;

    ctx.fillStyle = "rgb(0,0,0)";
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = "rgba(60,255,120,0.18)";
    ctx.lineWidth = Math.max(1, 1 * dpr);
    ctx.strokeRect(Math.floor(0.5 * dpr), Math.floor(0.5 * dpr), w - Math.floor(1 * dpr), h - Math.floor(1 * dpr));

    const s = clamp(sync, 0, 1);
    const c = clamp(corr, 0, 1);

    const cx = w * 0.5;
    const cy = h * 0.55;
    const r = Math.min(w, h) * 0.34;

    const jitter = (1 - s) * (0.55 + 0.65 * c);
    const a = 1 + 2.8 * (1 - s);
    const b = 1;

    ctx.beginPath();
    const steps = 220;
    for (let i = 0; i <= steps; i++) {
      const p = (i / steps) * Math.PI * 2;
      const n1 = Math.sin((t * 0.004 + i) * 1.7) * jitter;
      const n2 = Math.cos((t * 0.003 + i) * 1.3) * jitter;

      const x = cx + r * Math.sin(p * a + 0.2) + n1 * r * 0.12;
      const y = cy + r * Math.cos(p * b) + n2 * r * 0.12;

      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }

    ctx.strokeStyle = "rgba(60,255,120,0.85)";
    ctx.lineWidth = Math.max(1, 1.25 * dpr);
    ctx.stroke();

    if (s > 0.92) {
      ctx.fillStyle = "rgba(88,255,174,0.9)";
      ctx.beginPath();
      ctx.arc(cx, cy, 1.2 * dpr, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  resize();
  window.addEventListener("resize", resize, { passive: true });
  return { resize, draw };
}

function createBarsRenderer(canvas) {
  if (!canvas) return null;
  const ctx = canvas.getContext("2d", { alpha: false });
  let dpr = 1;
  let w = 0;
  let h = 0;

  function resize() {
    dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
    const cssW = canvas.clientWidth || 300;
    const cssH = 34;
    canvas.style.height = cssH + "px";
    canvas.width = Math.floor(cssW * dpr);
    canvas.height = Math.floor(cssH * dpr);
    w = canvas.width;
    h = canvas.height;
  }

  function draw(t, sync, corr) {
    if (!w || !h) return;
    ctx.fillStyle = "rgb(0,0,0)";
    ctx.fillRect(0, 0, w, h);

    const s = clamp(sync, 0, 1);
    const c = clamp(corr, 0, 1);

    const bins = 26;
    const gap = Math.floor(2 * dpr);
    const bw = Math.floor((w - gap * (bins - 1)) / bins);

    for (let i = 0; i < bins; i++) {
      const x = i * (bw + gap);
      const chaos = (Math.sin(t * 0.006 + i * 0.9) + Math.sin(t * 0.002 + i * 1.7)) * 0.5;
      const noise = (0.5 + 0.5 * chaos) * (1 - s) * (0.65 + 0.7 * c);
      const plateau = 0.22 + 0.55 * s;

      const v = clamp(plateau + noise, 0.05, 1);
      const barH = Math.floor(v * (h - 2 * dpr));

      ctx.fillStyle = "rgba(60,255,120,0.65)";
      ctx.fillRect(x, h - barH, bw, barH);
    }

    ctx.fillStyle = "rgba(255,255,255,0.04)";
    ctx.fillRect(0, 0, w, Math.floor(1 * dpr));
  }

  resize();
  window.addEventListener("resize", resize, { passive: true });
  return { resize, draw };
}

// ----------------------------
// Synchronicity math (Phase 1 win condition)
// ----------------------------
function syncTick(api, dt) {
  const d = ensurePhaseData(api);
  if (d.complete) return;

  const s = clamp(d.sync, 0, 1);
  const corr = clamp(api.state.corruption || 0, 0, 1);

  const f = lvl(api.state, "p1_filter");
  const g = lvl(api.state, "p1_gain");
  const n = lvl(api.state, "p1_cancel");
  const h = lvl(api.state, "p1_lock");
  const q = lvl(api.state, "p1_bias");

  const sig = Math.max(0, api.state.signal || 0);
  const signalPressure = clamp(Math.log10(sig + 10) / 7.2, 0, 1);

  const chain = clamp(d._pingChain || 0, 0, 20);

  // Faster early progression + a cadence reward so active play feels impactful.
  let growth = (0.00092 + 0.00135 * signalPressure);
  growth *= 1 + 0.30 * f;
  growth *= 1 + 0.012 * chain;

  const sOwned = (f > 0) + (lvl(api.state, "p1_surge") > 0) + (g > 0) + (n > 0) + (h > 0) + (q > 0);
  growth *= 1 + 0.45 * h * Math.max(0, sOwned - 1);

  // Corruption should hurt, but not hard-lock progress.
  // Noise Canceller reduces the bite.
  const corrBite = 0.35 * corr * (1 - clamp(0.18 * n, 0, 0.55));
  growth *= 1 - corrBite;

  const post30 = Math.max(0, s - 0.30);
  let drag = 0.00018 + 0.00185 * post30 * post30;
  drag *= 0.50 + 1.05 * corr;
  drag *= 1 - clamp(0.28 * n, 0, 0.70);

  const surf = q > 0 ? (0.00022 * q * corr) : 0;

  d.sync = clamp(s + (growth - drag + surf) * dt, 0, 1);

  if (d.sync >= 1) {
    d.complete = true;
    d.endAtMs = Date.now();
    const timeSec = (d.endAtMs - d.startAtMs) / 1000;
    const timeMs = Math.floor(d.endAtMs - d.startAtMs);

    if (!d.bestTimeSec || timeSec < d.bestTimeSec) d.bestTimeSec = timeSec;
    const best = d.bestTimeSec ? fmtTime(d.bestTimeSec) : fmtTime(timeSec);

    api.ui.popup("CONTROL", `SYNCHRONICITY ACHIEVED. TIME: ${fmtTime(timeSec)}. BEST: ${best}.`);
    api.ui.pushLog("log", "SYS", `PHASE 1 COMPLETE. TIME ${fmtTime(timeSec)}.`);

    // Global leaderboard submission (best time per user per phase)
    // Non-blocking: if the table/RLS isn't configured yet, the run still completes.
    (async () => {
      try {
        if (api.saves?.isSignedIn?.()) {
          await api.saves.submitPhaseBest({
            phase: PHASE_ID,
            timeMs,
            username: api.state?.profile?.name || "UNKNOWN",
          });
        }
      } catch (e) {
        // Log only; don't spam popups.
        api.ui.pushLog("log", "SYS", `LEADERBOARD SUBMIT FAILED: ${String(e?.message || e)}`);
      }
    })();

    const replayBtn = document.getElementById("p1Replay");
    if (replayBtn) replayBtn.style.display = "";
    api.touch();
  }
}

// ----------------------------
// Phase module
// ----------------------------
export default {
  id: PHASE_ID,
  name: "ARCTIC SKYWATCH: EXPLORATION",

  enter(api) {
    const { ui, audio, state } = api;

    const d = ensurePhaseData(api);

    // Runtime-only renderer handles must never persist across refresh.
    // If they were accidentally serialized in an older save, force-reset here.
    d._osc = null;
    d._bars = null;
    if (!d.startAtMs) d.startAtMs = Date.now();

    ui.monitor("ARCTIC SKYWATCH ONLINE. SWF DIRECTIVE: POINT DISH INTO THE BLACK.");
    ui.pushLog("log", "CONTROL", "PHASE 1: EXPLORATION PROTOCOLS LOADED.");
    ui.pushLog("log", "OPS", "PING THE VOID. LOOK FOR A RETURN.");

    // Scripted intro comms (fires once)
    {
      const flags = ensureCommsFlags(d);
      if (!flags.began) {
        flags.began = true;

        p1Say(api, P1_CAST.SWF, pick([
          "You are operating under SkyWatch Faction authority. Keep this channel clean. No narrative. No curiosity.",
          "Directive BLACKOUT is active. Do your work. Do not ask what the work is for.",
          "This facility does not exist in writing. Neither do you, if you mishandle this."
        ]));

        p1Say(api, P1_CAST.CONTROL, pick([
          "Arctic SkyWatch: online. Task begins now. Use PING to sample the designated region until a return pattern forms.",
          "Begin scan protocol. PING the void. We require twenty clean samples to confirm a return.",
          "Steady cadence. PING is your probe. Twenty returns establishes lock conditions."
        ]));

        p1Say(api, P1_CAST.OPS, pick([
          "Alright, scientist. First job: hit PING until we get a return. Then you buy buffs and let the rig do the heavy lifting.",
          "We poke the dark. Dark pokes back. Twenty pings gets us a return, then upgrades turn effort into momentum.",
          "Try not to speedrun finger cramps. Get the return, then feed the machine with buffs."
        ]));

        p1Say(api, P1_CAST.TECH, pick([
          "Dish is stable. Atmospherics are quiet… which usually means something else is loud.",
          "I’ll watch the waveform. You just keep the pings consistent. Patterns don’t like impatience.",
          "If the return is real, it’ll start repeating. Repetition is how ghosts and signals announce themselves."
        ]));
      }
    }

    ensurePhase1HUD(api);

    ensureSingleMusic(audio);
    if (audio?.register) {
      audio.register(
        MUSIC_KEY,
        async (a) => {
          let buf;
          try {
            buf = await a.loadBuffer(MUSIC_SRC_PRIMARY);
          } catch (e) {
            buf = await a.loadBuffer(MUSIC_SRC_FALLBACK);
          }
          return a.loopingSource(buf, { bus: "music", gain: 0.5, fadeIn: 2.0 });
        },
        { bus: "music" }
      );
    }
    audio?.play?.(MUSIC_KEY, { fadeIn: 2.0 });

    state.up ||= {};
    for (const b of P1_BUFFS) {
      if (!(b.id in state.up)) state.up[b.id] = 0;
    }

    d._autosaveAccum = 0;
    d._cloudSaveAccum = 0;
    d._commsAccum = 0;
    d._aiPulseAccum = 0;

    api.touch();
  },

  exit(api) {
    teardownPhase1HUD(api);
    api.audio?.stop?.(MUSIC_KEY, { fadeOut: 1.0 });
    if (window.__sygn1l_currentMusicKey === MUSIC_KEY) window.__sygn1l_currentMusicKey = null;
  },

  filterUpgrades(_upgrades, api) {
    const d = ensurePhaseData(api);
    if (d.pings < 20) return [];
    return P1_BUFFS;
  },

  modifyClickGain(base, api) {
    const d = ensurePhaseData(api);

    if (d.pings < 20) return 1;

    let g = base;

    const filterLv = lvl(api.state, "p1_filter");
    const surgeLv = lvl(api.state, "p1_surge");
    const gainLv = lvl(api.state, "p1_gain");
    const lockLv = lvl(api.state, "p1_lock");
    const biasLv = lvl(api.state, "p1_bias");

    // Reward cadence: consistent pings ramp click output.
    const chain = clamp(d._pingChain || 0, 0, 20);
    g *= 1 + 0.15 * chain;

    // Buffs: aggressive multipliers (Phase 1 needs a breakthrough moment)
    if (filterLv > 0) g *= 1.25;
    if (gainLv > 0) g *= 1.60;

    const owned =
      (lvl(api.state, "p1_filter") > 0) +
      (lvl(api.state, "p1_surge") > 0) +
      (lvl(api.state, "p1_gain") > 0) +
      (lvl(api.state, "p1_cancel") > 0) +
      (lvl(api.state, "p1_lock") > 0) +
      (lvl(api.state, "p1_bias") > 0);

    // Synergy engine: the more buffs, the harder this punches.
    g *= 1 + 0.14 * lockLv * Math.max(0, owned - 1);

    // "Illegal" surge window: x5 for a short time after ping.
    if (surgeLv > 0 && (d._surgeTimer || 0) > 0) g *= 1 + 4.0 * surgeLv;

    if (biasLv > 0) {
      const c = clamp(api.state.corruption || 0, 0, 1);
      g *= 1 + 0.20 * biasLv * c;
    }

    return g;
  },

  onPing(api) {
    const d = ensurePhaseData(api);
    d.pings++;

    // Ping momentum: reward cadence. Chain decays fast if you stop.
    d._pingChain = Math.min(20, (d._pingChain || 0) + 1);
    d._pingChainHold = 1.8;

    // SIGNAL SURGE: brief overpowered window after each ping
    const surgeLv = lvl(api.state, "p1_surge");
    if (surgeLv > 0) d._surgeTimer = 6.0;

    const flags = ensureCommsFlags(d);

    // Mark activity for AI gating (doesn't affect scripted comms)
    api.ai?.markActive?.();

    if (!flags.firstPing) {
      flags.firstPing = true;
      p1Say(api, P1_CAST.CONTROL, pick([
        "Acknowledged. Continue. One ping is noise. A sequence becomes evidence.",
        "Good. Maintain cadence. We are constructing a baseline from nothing.",
        "Proceed. Repeat PING until a return can be distinguished from static."
      ]));
    }

    if (d.pings === 10 && !flags.ping10) {
      flags.ping10 = true;
      p1Say(api, P1_CAST.TECH, pick([
        "I’m seeing smear on the edges of the trace. Not wind. Not power. Something… answering late.",
        "There’s a wobble that shouldn’t be there. Either the dish is haunted, or you’re close. I’m betting close.",
        "The noise floor is doing a little dance. That’s either interference… or a hello."
      ]));
      p1Say(api, P1_CAST.OPS, pick([
        "Halfway to a return. Keep tapping. We just need enough samples that the void can’t pretend it’s innocent.",
        "Ten down. Ten to go. Then you can stop poking it and start farming it.",
        "Good. Don’t drift. Consistency is how you catch a liar."
      ]));
    }

    if (d.pings === 20 && !flags.gotReturn) {
      flags.gotReturn = true;

      api.state.signal = Math.max(api.state.signal, 20);
      api.state.total = Math.max(api.state.total, 20);

      p1Say(api, P1_CAST.CONTROL, pick([
        "Return acquired. Phase objective shifts. Deploy buffs to increase signal/sec, then drive synchronicity to completion.",
        "Return confirmed. You may now apply upgrades. Allow passive gain to build momentum.",
        "We have a hook. Now we stabilize it. Buffs will convert time into signal. Pursue synchronicity."
      ]));
      p1Say(api, P1_CAST.OPS, pick([
        "There it is. Now buy your first buff and watch the meter start walking by itself.",
        "Congrats. You found the thread. Now don’t yank it, weave it. Upgrades first, panic later.",
        "Cool. This is where you stop mashing and start engineering."
      ]));
      p1Say(api, P1_CAST.SWF, pick([
        "Return recognized. Your continued employment depends on what you do next: complete the lock.",
        "You have what we needed. Do not create an incident by improvising.",
        "Proceed to synchronicity. Do not share observations. Do not record interpretations."
      ]));

      api.ui.popup("CONTROL", "Return acquired. Buffs are now available.");
      api.ui.pushLog("comms", "CONTROL", "RETURN SIGNAL LOCKED. BUFF PROTOCOLS UNSEALED.");

      d.startAtMs = Date.now();
      api.touch();

      // Force-save right when the run begins so refresh doesn't zero you
      try { api.saves?.saveLocal?.(api.state); } catch (e) {}
      try { api.saves?.writeCloudState?.(api.state, false); } catch (e) {}
    }

    // Cryo Amp tradeoff: slightly increases corruption per ping
    const gainLv = lvl(api.state, "p1_gain");
    if (gainLv > 0) {
      api.state.corruption = clamp((api.state.corruption || 0) + 0.00010 * gainLv, 0, 1);
    }
  },

  tick(api, dt) {
    const d = ensurePhaseData(api);

    // Defensive: if older saves accidentally persisted these as plain objects,
    // they block initialisation and the canvases look "dead" after refresh.
    if (d._osc && typeof d._osc.draw !== "function") d._osc = null;
    if (d._bars && typeof d._bars.draw !== "function") d._bars = null;

    // ----------------------------
    // Ping momentum + surge timers
    // ----------------------------
    if (d._pingChainHold > 0) d._pingChainHold = Math.max(0, d._pingChainHold - dt);
    else d._pingChain = Math.max(0, (d._pingChain || 0) - dt * 1.85);

    if (d._surgeTimer > 0) d._surgeTimer = Math.max(0, d._surgeTimer - dt);

    // ----------------------------
    // Phase-local autosave
    // ----------------------------
    d._autosaveAccum += dt;
    d._cloudSaveAccum += dt;

    if (d._autosaveAccum >= 6) {
      d._autosaveAccum = 0;
      api.touch();
      try { api.saves?.saveLocal?.(api.state); } catch (e) {}
    }

    if (d._cloudSaveAccum >= 20) {
      d._cloudSaveAccum = 0;
      try { api.saves?.writeCloudState?.(api.state, false); } catch (e) {}
    }

    // Win condition only after the return is acquired
    if (d.pings >= 20) syncTick(api, dt);

    // ----------------------------
    // Phase 1 passive gain
    // ----------------------------
    if (d.pings >= 20 && !d.complete) {
      const f = lvl(api.state, "p1_filter");
      const surgeLv = lvl(api.state, "p1_surge");
      const g = lvl(api.state, "p1_gain");
      const n = lvl(api.state, "p1_cancel");
      const h = lvl(api.state, "p1_lock");
      const q = lvl(api.state, "p1_bias");

      // Phase 1 needs multipliers that can actually outrun corruption.
      // Build base, then stack multipliers for a real "breakthrough".
      let sps = 0.055;
      let mult = 1;

      // Core multipliers (more aggressive than before)
      if (f > 0) mult *= 1.45;
      if (g > 0) mult *= 2.10;
      if (n > 0) mult *= 1.80;

      // Cadence reward: sustained pings improve passive output too.
      const chain = clamp(d._pingChain || 0, 0, 20);
      mult *= 1 + 0.08 * chain;

      const owned = (f > 0) + (surgeLv > 0) + (g > 0) + (n > 0) + (h > 0) + (q > 0);
      mult *= 1 + 0.60 * h * Math.max(0, owned - 1);

      const corr = clamp(api.state.corruption || 0, 0, 1);
      // Corruption drag, softened, and strongly mitigated by NOISE CANCELLER.
      const drag = 0.55 * corr * (1 - clamp(0.20 * n, 0, 0.65));
      mult *= 1 - drag;

      // QUANTUM PHASE BIAS: corruption becomes fuel.
      if (q > 0) mult *= 1 + 0.55 * q * corr;

      // Sync makes everything more stable (late-phase ramp)
      mult *= 1 + 0.55 * clamp(d.sync, 0, 1);

      // SIGNAL SURGE also slightly improves passive while active (tiny bleed into idle)
      if (surgeLv > 0 && (d._surgeTimer || 0) > 0) mult *= 1.35;

      sps *= Math.max(0.05, mult);

      const delta = Math.max(0, sps) * dt;
      api.state.signal = (api.state.signal || 0) + delta;
      api.state.total = (api.state.total || 0) + delta;

      d._p1_sps = sps;
    }

    // Corruption relief
    const cancelLv = lvl(api.state, "p1_cancel");
    if (cancelLv > 0) {
      // Much stronger than before: this is the core counterplay.
      api.state.corruption = clamp((api.state.corruption || 0) - 0.000040 * cancelLv * dt, 0, 1);
    }

    // SIGNAL SURGE: active "get ahead" window bleeds corruption faster.
    const surgeLv = lvl(api.state, "p1_surge");
    if (surgeLv > 0 && (d._surgeTimer || 0) > 0) {
      api.state.corruption = clamp((api.state.corruption || 0) - 0.000090 * surgeLv * dt, 0, 1);
    }

    // ----------------------------
    // Phase-local AI comms (optional background flavour)
    // ----------------------------
    d._commsAccum += dt;
    d._aiPulseAccum += dt;

    if (d._commsAccum >= 55) {
      d._commsAccum = 0;
      api.ai?.maybeAmbient?.(api.state);
    }

    if (d._aiPulseAccum >= 75) {
      d._aiPulseAccum = 0;
      if (d.pings >= 20 && d.sync < 0.35) api.ai?.invokeEdge?.(api.state, "phase1_early", "CONTROL");
      else if (d.sync >= 0.35 && d.sync < 0.85) api.ai?.invokeEdge?.(api.state, "phase1_mid", "OPS");
      else if (d.sync >= 0.85 && !d.complete) api.ai?.invokeEdge?.(api.state, "phase1_final", "SWF");
    }

    // ----------------------------
    // HUD + scripted milestone comms
    // ----------------------------
    const tNow = Date.now();
    const elapsed = d.pings >= 20 ? (tNow - (d.startAtMs || tNow)) / 1000 : 0;

    const chip = document.getElementById("p1TimerChip");
    if (chip)
      chip.textContent = d.complete
        ? `DONE ${fmtTime((d.endAtMs - d.startAtMs) / 1000)}`
        : `T+ ${fmtTime(elapsed)}`;

    const s = clamp(d.sync, 0, 1);
    const corr = clamp(api.state.corruption || 0, 0, 1);
    const syncPct = s * 100;
    const flags = ensureCommsFlags(d);

    // First buff purchased
    if (!flags.firstBuff && d.pings >= 20) {
      const owned =
        (lvl(api.state, "p1_filter") > 0) +
        (lvl(api.state, "p1_surge") > 0) +
        (lvl(api.state, "p1_gain") > 0) +
        (lvl(api.state, "p1_cancel") > 0) +
        (lvl(api.state, "p1_lock") > 0) +
        (lvl(api.state, "p1_bias") > 0);

      if (owned >= 1) {
        flags.firstBuff = true;
        p1Say(api, P1_CAST.OPS, pick([
          "There. Hear that? That’s the sound of not doing everything yourself. Signal/sec is online.",
          "Good. Now the machine earns while you think. Stack buffs that multiply, not just add.",
          "Nice. Now stop feeding it crumbs. Build a pipeline."
        ]));
        p1Say(api, P1_CAST.TECH, pick([
          "Waveform looks… less angry. Buffs are smoothing the return. Keep going.",
          "Okay, that helped. The trace is still skittish, but it’s got a rhythm now.",
          "If this were a campfire story, this is the part where the wind stops. I don’t love it."
        ]));
      }
    }

    // Sync milestones
    if (s >= 0.30 && !flags.hit30) {
      flags.hit30 = true;
      p1Say(api, P1_CAST.CONTROL, pick([
        "Synchronicity at thirty percent. Threshold crossed. Expect increased resistance from corruption.",
        "Thirty percent achieved. From this point, stability requires strategy. Continue.",
        "We are no longer searching. We are aligning. Maintain momentum."
      ]));
      p1Say(api, P1_CAST.OPS, pick([
        "30%: tutorial’s over. Now it fights back. Don’t let your passive gain sag.",
        "You’re in the zone where people stall and blame the universe. Buy smarter.",
        "Good pace. Keep it. Corruption will start punching above its weight now."
      ]));
    }

    if (s >= 0.60 && !flags.hit60) {
      flags.hit60 = true;
      p1Say(api, P1_CAST.OPS, pick([
        "60%: this is the plateau cliff. If you’re not stacking synergies, you’re hiking in flip-flops.",
        "Halfway is a trap. One multiplier beats three tiny boosts. Act accordingly.",
        "If it slows here, it’s not bad luck. It’s your build."
      ]));
      p1Say(api, P1_CAST.TECH, pick([
        "The trace is trying to become a circle. It’s… weirdly satisfying. Also ominous.",
        "I’m seeing the oscillation tighten. Like it knows where it wants to be.",
        "If this thing starts syncing with the facility clock, I’m unplugging something."
      ]));
    }

    if (s >= 0.85 && !flags.hit85) {
      flags.hit85 = true;
      p1Say(api, P1_CAST.SWF, pick([
        "You are approaching a sensitive threshold. Finish the lock. Do not linger.",
        "If you experience… anomalies, you will ignore them and proceed.",
        "Do not celebrate early. Complete the task. Then we will discuss whether you are permitted to remember it."
      ]));
      p1Say(api, P1_CAST.CONTROL, pick([
        "Eighty-five percent. Final approach. Keep corruption contained and maintain signal momentum.",
        "Near-lock conditions. Continue until full synchronicity is achieved.",
        "Hold course. Complete alignment."
      ]));
    }

    // Corruption alerts
    if (corr >= 0.25 && !flags.corr25) {
      flags.corr25 = true;
      p1Say(api, P1_CAST.TECH, pick([
        "Corruption is climbing. It’s like static with intent. You’ll feel it in the drag.",
        "Quarter corruption. The trace is getting… spiteful. Noise Canceller helps.",
        "I don’t want to anthropomorphize it, but it’s acting like it’s annoyed."
      ]));
      p1Say(api, P1_CAST.OPS, pick([
        "Corruption’s up. Don’t brute force it. Mitigate it or outrun it, your call.",
        "If signal growth feels sticky, that’s corruption chewing the edges. Fix it.",
        "Keep the machine fed, but don’t pour fuel into a leak."
      ]));
    }

    if (corr >= 0.50 && !flags.corr50) {
      flags.corr50 = true;
      p1Say(api, P1_CAST.CONTROL, pick([
        "Corruption at fifty percent. Primary threat. Stabilize or progress will degrade.",
        "High corruption. Apply countermeasures immediately.",
        "Warning: corruption dominance approaching. Maintain control."
      ]));
      p1Say(api, P1_CAST.SWF, pick([
        "You will not allow contamination to propagate beyond this phase. Understood?",
        "If you cannot control it, you will contain it. Failure is not an option we budgeted for.",
        "You are accountable for what you wake."
      ]));
    }

    // Gentle reminder every ~90s after return if player seems stuck
    if (d.pings >= 20 && !d.complete) {
      flags.reminderIdle += dt;
      if (flags.reminderIdle >= 90) {
        flags.reminderIdle = 0;

        const p1sps = d._p1_sps || 0;
        if (s < 0.45 && p1sps < 1.2) {
          p1Say(api, P1_CAST.OPS, pick([
            "If you’re still clicking for rent money, your passive gain is underbuilt. Fix it.",
            "Buy something that boosts signal/sec. Let time do the boring work.",
            "You’re allowed to stop mashing. That’s what buffs are for."
          ]));
          p1Say(api, P1_CAST.CONTROL, pick([
            "Recommendation: increase passive gain. Maintain cadence. Continue scan-to-lock protocol.",
            "Adjust strategy. Passive accumulation is required to progress efficiently.",
            "Upgrade to sustain momentum."
          ]));
        }
      }
    }

    // HUD DOM updates
    const oscLabel = document.getElementById("p1OscLabel");
    if (oscLabel) oscLabel.textContent = `SYNC: ${syncPct.toFixed(0)}%`;

    const meta = document.getElementById("p1SyncMeta");
    if (meta) meta.textContent = `${syncPct.toFixed(1)}%`;

    const fill = document.getElementById("p1SyncFill");
    if (fill) fill.style.width = `${syncPct.toFixed(2)}%`;

    const spsChip = document.getElementById("p1SpsChip");
    if (spsChip) spsChip.textContent = `P1 +${(d._p1_sps || 0).toFixed(2)}/s`;

    // Render canvases
    const oscCanvas = document.getElementById("p1Osc");
    const barsCanvas = document.getElementById("p1Bars");

    if (!d._osc && oscCanvas) d._osc = createOscRenderer(oscCanvas);
    if (!d._bars && barsCanvas) d._bars = createBarsRenderer(barsCanvas);

    const corrNow = api.state.corruption || 0;
    d._osc?.draw?.(tNow, d.sync, corrNow);
    d._bars?.draw?.(tNow, d.sync, corrNow);

    const pingBtn = document.getElementById("ping");
    if (pingBtn) {
      if (d.pings < 20) pingBtn.classList.add("afford");
      else pingBtn.classList.remove("afford");
    }

    if (!d.complete) {
      if (d.pings < 20) api.ui.monitor(`SCANNING… ${d.pings}/20 PINGS`);
      else if (d.sync < 0.30)
        api.ui.monitor(`RETURN ACQUIRED. SEEK COHERENCE. SYNC ${syncPct.toFixed(1)}%  •  P1 +${(d._p1_sps || 0).toFixed(2)}/s`);
      else
        api.ui.monitor(`CORRUPTION PUSHBACK DETECTED. HOLD THE LINE. SYNC ${syncPct.toFixed(1)}%  •  P1 +${(d._p1_sps || 0).toFixed(2)}/s`);
    }
  }
};